<?php
namespace WP_Stream;

class Test_WP_Stream_Connector_Posts extends WP_StreamTestCase {

}
